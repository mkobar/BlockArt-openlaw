## Kaleido.io samples gallery

* A collection of samples hosted [here](https://kaleido-io.github.io/kaleido-samples-gallery/)

* **[OpenLaw API](./docs/openlaw)** A demonstration of how to create legally binding, blockchain-enabled contracts on a Kaleido private network.
